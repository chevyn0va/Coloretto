﻿namespace Coloretto
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.take1 = new System.Windows.Forms.Button();
            this.take2 = new System.Windows.Forms.Button();
            this.take3 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.playerPlus = new System.Windows.Forms.Label();
            this.playerBlue = new System.Windows.Forms.Label();
            this.playerGreen = new System.Windows.Forms.Label();
            this.playerJoker = new System.Windows.Forms.Label();
            this.playerPink = new System.Windows.Forms.Label();
            this.playerYellow = new System.Windows.Forms.Label();
            this.playerRed = new System.Windows.Forms.Label();
            this.compPlus = new System.Windows.Forms.Label();
            this.compBlue = new System.Windows.Forms.Label();
            this.compGreen = new System.Windows.Forms.Label();
            this.compJoker = new System.Windows.Forms.Label();
            this.compPink = new System.Windows.Forms.Label();
            this.compYellow = new System.Windows.Forms.Label();
            this.compRed = new System.Windows.Forms.Label();
            this.lastCard = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.jokerComp = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.greenComp = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.blueComp = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.plusComp = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.currentCard = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.lastCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jokerComp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenComp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueComp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plusComp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.currentCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(32, 120);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Draw Card";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(342, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Row One";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(341, 154);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Row Two";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(338, 267);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Row Three";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 267);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Drawn Card";
            // 
            // take1
            // 
            this.take1.Location = new System.Drawing.Point(329, 72);
            this.take1.Name = "take1";
            this.take1.Size = new System.Drawing.Size(75, 23);
            this.take1.TabIndex = 13;
            this.take1.Text = "Take Row";
            this.take1.UseVisualStyleBackColor = true;
            this.take1.Click += new System.EventHandler(this.take1_Click);
            // 
            // take2
            // 
            this.take2.Location = new System.Drawing.Point(329, 170);
            this.take2.Name = "take2";
            this.take2.Size = new System.Drawing.Size(75, 23);
            this.take2.TabIndex = 14;
            this.take2.Text = "Take Row";
            this.take2.UseVisualStyleBackColor = true;
            this.take2.Click += new System.EventHandler(this.take2_Click);
            // 
            // take3
            // 
            this.take3.Location = new System.Drawing.Point(330, 283);
            this.take3.Name = "take3";
            this.take3.Size = new System.Drawing.Size(75, 23);
            this.take3.TabIndex = 15;
            this.take3.Text = "Take Row";
            this.take3.UseVisualStyleBackColor = true;
            this.take3.Click += new System.EventHandler(this.take3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 373);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Player\'s Hand";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(373, 373);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Computer\'s Hand";
            // 
            // playerPlus
            // 
            this.playerPlus.AutoSize = true;
            this.playerPlus.Location = new System.Drawing.Point(24, 502);
            this.playerPlus.Name = "playerPlus";
            this.playerPlus.Size = new System.Drawing.Size(13, 13);
            this.playerPlus.TabIndex = 18;
            this.playerPlus.Text = "0";
            this.playerPlus.Click += new System.EventHandler(this.playerPlus_Click);
            // 
            // playerBlue
            // 
            this.playerBlue.AutoSize = true;
            this.playerBlue.Location = new System.Drawing.Point(89, 502);
            this.playerBlue.Name = "playerBlue";
            this.playerBlue.Size = new System.Drawing.Size(13, 13);
            this.playerBlue.TabIndex = 18;
            this.playerBlue.Text = "0";
            // 
            // playerGreen
            // 
            this.playerGreen.AutoSize = true;
            this.playerGreen.Location = new System.Drawing.Point(158, 502);
            this.playerGreen.Name = "playerGreen";
            this.playerGreen.Size = new System.Drawing.Size(13, 13);
            this.playerGreen.TabIndex = 18;
            this.playerGreen.Text = "0";
            // 
            // playerJoker
            // 
            this.playerJoker.AutoSize = true;
            this.playerJoker.Location = new System.Drawing.Point(225, 502);
            this.playerJoker.Name = "playerJoker";
            this.playerJoker.Size = new System.Drawing.Size(13, 13);
            this.playerJoker.TabIndex = 18;
            this.playerJoker.Text = "0";
            // 
            // playerPink
            // 
            this.playerPink.AutoSize = true;
            this.playerPink.Location = new System.Drawing.Point(56, 640);
            this.playerPink.Name = "playerPink";
            this.playerPink.Size = new System.Drawing.Size(13, 13);
            this.playerPink.TabIndex = 18;
            this.playerPink.Text = "0";
            // 
            // playerYellow
            // 
            this.playerYellow.AutoSize = true;
            this.playerYellow.Location = new System.Drawing.Point(119, 640);
            this.playerYellow.Name = "playerYellow";
            this.playerYellow.Size = new System.Drawing.Size(13, 13);
            this.playerYellow.TabIndex = 18;
            this.playerYellow.Text = "0";
            // 
            // playerRed
            // 
            this.playerRed.AutoSize = true;
            this.playerRed.Location = new System.Drawing.Point(191, 640);
            this.playerRed.Name = "playerRed";
            this.playerRed.Size = new System.Drawing.Size(13, 13);
            this.playerRed.TabIndex = 18;
            this.playerRed.Text = "0";
            // 
            // compPlus
            // 
            this.compPlus.AutoSize = true;
            this.compPlus.Location = new System.Drawing.Point(373, 502);
            this.compPlus.Name = "compPlus";
            this.compPlus.Size = new System.Drawing.Size(13, 13);
            this.compPlus.TabIndex = 18;
            this.compPlus.Text = "0";
            // 
            // compBlue
            // 
            this.compBlue.AutoSize = true;
            this.compBlue.Location = new System.Drawing.Point(442, 502);
            this.compBlue.Name = "compBlue";
            this.compBlue.Size = new System.Drawing.Size(13, 13);
            this.compBlue.TabIndex = 18;
            this.compBlue.Text = "0";
            // 
            // compGreen
            // 
            this.compGreen.AutoSize = true;
            this.compGreen.Location = new System.Drawing.Point(509, 502);
            this.compGreen.Name = "compGreen";
            this.compGreen.Size = new System.Drawing.Size(13, 13);
            this.compGreen.TabIndex = 18;
            this.compGreen.Text = "0";
            // 
            // compJoker
            // 
            this.compJoker.AutoSize = true;
            this.compJoker.Location = new System.Drawing.Point(578, 502);
            this.compJoker.Name = "compJoker";
            this.compJoker.Size = new System.Drawing.Size(13, 13);
            this.compJoker.TabIndex = 18;
            this.compJoker.Text = "0";
            // 
            // compPink
            // 
            this.compPink.AutoSize = true;
            this.compPink.Location = new System.Drawing.Point(405, 640);
            this.compPink.Name = "compPink";
            this.compPink.Size = new System.Drawing.Size(13, 13);
            this.compPink.TabIndex = 18;
            this.compPink.Text = "0";
            // 
            // compYellow
            // 
            this.compYellow.AutoSize = true;
            this.compYellow.Location = new System.Drawing.Point(472, 640);
            this.compYellow.Name = "compYellow";
            this.compYellow.Size = new System.Drawing.Size(13, 13);
            this.compYellow.TabIndex = 18;
            this.compYellow.Text = "0";
            // 
            // compRed
            // 
            this.compRed.AutoSize = true;
            this.compRed.Location = new System.Drawing.Point(545, 640);
            this.compRed.Name = "compRed";
            this.compRed.Size = new System.Drawing.Size(13, 13);
            this.compRed.TabIndex = 18;
            this.compRed.Text = "0";
            // 
            // lastCard
            // 
            this.lastCard.Location = new System.Drawing.Point(109, 26);
            this.lastCard.Name = "lastCard";
            this.lastCard.Size = new System.Drawing.Size(61, 92);
            this.lastCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lastCard.TabIndex = 20;
            this.lastCard.TabStop = false;
            this.lastCard.Click += new System.EventHandler(this.lastCard_Click);
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox21.Image")));
            this.pictureBox21.Location = new System.Drawing.Point(528, 545);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(61, 92);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox21.TabIndex = 17;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(179, 545);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(61, 92);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 17;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox20.Image")));
            this.pictureBox20.Location = new System.Drawing.Point(461, 545);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(61, 92);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 17;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(112, 545);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(61, 92);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 17;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::Coloretto.Properties.Resources.Purple;
            this.pictureBox19.Location = new System.Drawing.Point(394, 545);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(61, 92);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox19.TabIndex = 17;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::Coloretto.Properties.Resources.Purple;
            this.pictureBox12.Location = new System.Drawing.Point(45, 545);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(61, 92);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 17;
            this.pictureBox12.TabStop = false;
            // 
            // jokerComp
            // 
            this.jokerComp.Image = ((System.Drawing.Image)(resources.GetObject("jokerComp.Image")));
            this.jokerComp.Location = new System.Drawing.Point(561, 405);
            this.jokerComp.Name = "jokerComp";
            this.jokerComp.Size = new System.Drawing.Size(61, 92);
            this.jokerComp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.jokerComp.TabIndex = 17;
            this.jokerComp.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(212, 405);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(61, 92);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 17;
            this.pictureBox11.TabStop = false;
            // 
            // greenComp
            // 
            this.greenComp.Image = ((System.Drawing.Image)(resources.GetObject("greenComp.Image")));
            this.greenComp.Location = new System.Drawing.Point(494, 405);
            this.greenComp.Name = "greenComp";
            this.greenComp.Size = new System.Drawing.Size(61, 92);
            this.greenComp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.greenComp.TabIndex = 17;
            this.greenComp.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(145, 405);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(61, 92);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 17;
            this.pictureBox10.TabStop = false;
            // 
            // blueComp
            // 
            this.blueComp.Image = ((System.Drawing.Image)(resources.GetObject("blueComp.Image")));
            this.blueComp.Location = new System.Drawing.Point(427, 405);
            this.blueComp.Name = "blueComp";
            this.blueComp.Size = new System.Drawing.Size(61, 92);
            this.blueComp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blueComp.TabIndex = 17;
            this.blueComp.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(78, 405);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(61, 92);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 17;
            this.pictureBox9.TabStop = false;
            // 
            // plusComp
            // 
            this.plusComp.Image = ((System.Drawing.Image)(resources.GetObject("plusComp.Image")));
            this.plusComp.Location = new System.Drawing.Point(360, 405);
            this.plusComp.Name = "plusComp";
            this.plusComp.Size = new System.Drawing.Size(61, 92);
            this.plusComp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.plusComp.TabIndex = 17;
            this.plusComp.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(11, 405);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(61, 92);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 17;
            this.pictureBox8.TabStop = false;
            // 
            // currentCard
            // 
            this.currentCard.Location = new System.Drawing.Point(41, 170);
            this.currentCard.Name = "currentCard";
            this.currentCard.Size = new System.Drawing.Size(62, 92);
            this.currentCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.currentCard.TabIndex = 11;
            this.currentCard.TabStop = false;
            this.currentCard.Click += new System.EventHandler(this.currentCard_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.ImageLocation = "";
            this.pictureBox7.InitialImage = null;
            this.pictureBox7.Location = new System.Drawing.Point(409, 247);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(61, 95);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 7;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.ImageLocation = "";
            this.pictureBox6.InitialImage = null;
            this.pictureBox6.Location = new System.Drawing.Point(489, 131);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(61, 92);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.ImageLocation = "";
            this.pictureBox5.InitialImage = null;
            this.pictureBox5.Location = new System.Drawing.Point(409, 131);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(61, 92);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.ImageLocation = "";
            this.pictureBox4.InitialImage = null;
            this.pictureBox4.Location = new System.Drawing.Point(565, 26);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(61, 88);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.ImageLocation = "";
            this.pictureBox3.InitialImage = null;
            this.pictureBox3.Location = new System.Drawing.Point(489, 26);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(61, 88);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.ImageLocation = "";
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(409, 26);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(61, 88);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Coloretto.Properties.Resources.DeckTop;
            this.pictureBox1.Location = new System.Drawing.Point(42, 26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(61, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(78, 663);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(499, 50);
            this.textBox1.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 678);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 20);
            this.label9.TabIndex = 25;
            this.label9.Text = "Help";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(677, 750);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lastCard);
            this.Controls.Add(this.compRed);
            this.Controls.Add(this.compYellow);
            this.Controls.Add(this.compPink);
            this.Controls.Add(this.compJoker);
            this.Controls.Add(this.compGreen);
            this.Controls.Add(this.compBlue);
            this.Controls.Add(this.compPlus);
            this.Controls.Add(this.playerRed);
            this.Controls.Add(this.playerYellow);
            this.Controls.Add(this.playerPink);
            this.Controls.Add(this.playerJoker);
            this.Controls.Add(this.playerGreen);
            this.Controls.Add(this.playerBlue);
            this.Controls.Add(this.playerPlus);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.jokerComp);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.greenComp);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.blueComp);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.plusComp);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.take3);
            this.Controls.Add(this.take2);
            this.Controls.Add(this.take1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.currentCard);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Coloretto";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.lastCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jokerComp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenComp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueComp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plusComp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.currentCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox currentCard;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button take1;
        private System.Windows.Forms.Button take2;
        private System.Windows.Forms.Button take3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox plusComp;
        private System.Windows.Forms.PictureBox blueComp;
        private System.Windows.Forms.PictureBox greenComp;
        private System.Windows.Forms.PictureBox jokerComp;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.Label playerPlus;
        private System.Windows.Forms.Label playerBlue;
        private System.Windows.Forms.Label playerGreen;
        private System.Windows.Forms.Label playerJoker;
        private System.Windows.Forms.Label playerPink;
        private System.Windows.Forms.Label playerYellow;
        private System.Windows.Forms.Label playerRed;
        private System.Windows.Forms.Label compPlus;
        private System.Windows.Forms.Label compBlue;
        private System.Windows.Forms.Label compGreen;
        private System.Windows.Forms.Label compJoker;
        private System.Windows.Forms.Label compPink;
        private System.Windows.Forms.Label compYellow;
        private System.Windows.Forms.Label compRed;
        private System.Windows.Forms.PictureBox lastCard;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label9;
    }
}

