﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Diagnostics.Contracts;
using System.Windows.Forms;

namespace Coloretto
{
    /// <summary>
    /// Super class for cards, each type of card inherits from this class
    /// </summary>
    class CardClass
    {
        /// <summary>
        /// Ensures the playing deck contains valid objects
        /// </summary>
        [ContractInvariantMethod]
        private void ImageEditorInvariant()
        {
            Contract.Invariant(this.cardName != null);
            Contract.Invariant(this.cardType != null);
            Contract.Invariant(this.image != null);
            Contract.Invariant(this.imageLoc != null);
        }
        protected String cardName = "";
        protected String cardType = "";
        protected Bitmap image = new Bitmap("14.gif");
        protected String imageLoc = "";
        public CardClass()
        {
            cardName = "";
            cardType = "";
            image = new Bitmap("14.gif");
            imageLoc = "";
            Contract.Ensures(cardName != null);
            Contract.Ensures(cardType != null);
            Contract.Ensures(image != null);
            Contract.Ensures(imageLoc != null);
        }
        public Bitmap getImage()
        {
            return this.image;
        }
        public String getImageLoc()
        {
            return this.imageLoc;
        }
        public String getName()
        {
            return this.cardName;
        }
        public String getType()
        {
            return cardType;
        }

    }
}
