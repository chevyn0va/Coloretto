﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace Coloretto
{
    /// <summary>
    /// Subclass of cardclass
    /// Last Round card
    /// </summary>
    class EndGameCard : CardClass
    {
        public EndGameCard()
        {
            cardType = "Last Round";
            cardName = "Last Round card";
            image = new System.Drawing.Bitmap(@"26.gif");
            imageLoc = @"26.gif";
            Contract.Ensures(cardName != null);
            Contract.Ensures(cardType != null);
            Contract.Ensures(image != null);
            Contract.Ensures(imageLoc != null);
        }
    }
}
