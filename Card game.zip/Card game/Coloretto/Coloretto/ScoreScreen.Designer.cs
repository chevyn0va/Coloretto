﻿namespace Coloretto
{
    partial class ScoreScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.playerPlus = new System.Windows.Forms.Label();
            this.playerBlue = new System.Windows.Forms.Label();
            this.playerGreen = new System.Windows.Forms.Label();
            this.playerJoker = new System.Windows.Forms.Label();
            this.playerPink = new System.Windows.Forms.Label();
            this.playerYellow = new System.Windows.Forms.Label();
            this.playerRed = new System.Windows.Forms.Label();
            this.compPlus = new System.Windows.Forms.Label();
            this.compBlue = new System.Windows.Forms.Label();
            this.compGreen = new System.Windows.Forms.Label();
            this.compJoker = new System.Windows.Forms.Label();
            this.compPink = new System.Windows.Forms.Label();
            this.compYellow = new System.Windows.Forms.Label();
            this.compRed = new System.Windows.Forms.Label();
            this.plusComp = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.blueComp = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.greenComp = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.jokerComp = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.plusComp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueComp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenComp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jokerComp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Player\'s Hand";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(441, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Computer\'s Hand";
            // 
            // playerPlus
            // 
            this.playerPlus.AutoSize = true;
            this.playerPlus.Location = new System.Drawing.Point(20, 143);
            this.playerPlus.Name = "playerPlus";
            this.playerPlus.Size = new System.Drawing.Size(13, 13);
            this.playerPlus.TabIndex = 18;
            this.playerPlus.Text = "0";
            this.playerPlus.Click += new System.EventHandler(this.playerPlus_Click);
            // 
            // playerBlue
            // 
            this.playerBlue.AutoSize = true;
            this.playerBlue.Location = new System.Drawing.Point(85, 143);
            this.playerBlue.Name = "playerBlue";
            this.playerBlue.Size = new System.Drawing.Size(13, 13);
            this.playerBlue.TabIndex = 18;
            this.playerBlue.Text = "0";
            // 
            // playerGreen
            // 
            this.playerGreen.AutoSize = true;
            this.playerGreen.Location = new System.Drawing.Point(154, 143);
            this.playerGreen.Name = "playerGreen";
            this.playerGreen.Size = new System.Drawing.Size(13, 13);
            this.playerGreen.TabIndex = 18;
            this.playerGreen.Text = "0";
            // 
            // playerJoker
            // 
            this.playerJoker.AutoSize = true;
            this.playerJoker.Location = new System.Drawing.Point(221, 143);
            this.playerJoker.Name = "playerJoker";
            this.playerJoker.Size = new System.Drawing.Size(13, 13);
            this.playerJoker.TabIndex = 18;
            this.playerJoker.Text = "0";
            // 
            // playerPink
            // 
            this.playerPink.AutoSize = true;
            this.playerPink.Location = new System.Drawing.Point(52, 281);
            this.playerPink.Name = "playerPink";
            this.playerPink.Size = new System.Drawing.Size(13, 13);
            this.playerPink.TabIndex = 18;
            this.playerPink.Text = "0";
            // 
            // playerYellow
            // 
            this.playerYellow.AutoSize = true;
            this.playerYellow.Location = new System.Drawing.Point(115, 281);
            this.playerYellow.Name = "playerYellow";
            this.playerYellow.Size = new System.Drawing.Size(13, 13);
            this.playerYellow.TabIndex = 18;
            this.playerYellow.Text = "0";
            // 
            // playerRed
            // 
            this.playerRed.AutoSize = true;
            this.playerRed.Location = new System.Drawing.Point(187, 281);
            this.playerRed.Name = "playerRed";
            this.playerRed.Size = new System.Drawing.Size(13, 13);
            this.playerRed.TabIndex = 18;
            this.playerRed.Text = "0";
            // 
            // compPlus
            // 
            this.compPlus.AutoSize = true;
            this.compPlus.Location = new System.Drawing.Point(369, 143);
            this.compPlus.Name = "compPlus";
            this.compPlus.Size = new System.Drawing.Size(13, 13);
            this.compPlus.TabIndex = 18;
            this.compPlus.Text = "0";
            // 
            // compBlue
            // 
            this.compBlue.AutoSize = true;
            this.compBlue.Location = new System.Drawing.Point(438, 143);
            this.compBlue.Name = "compBlue";
            this.compBlue.Size = new System.Drawing.Size(13, 13);
            this.compBlue.TabIndex = 18;
            this.compBlue.Text = "0";
            // 
            // compGreen
            // 
            this.compGreen.AutoSize = true;
            this.compGreen.Location = new System.Drawing.Point(505, 143);
            this.compGreen.Name = "compGreen";
            this.compGreen.Size = new System.Drawing.Size(13, 13);
            this.compGreen.TabIndex = 18;
            this.compGreen.Text = "0";
            // 
            // compJoker
            // 
            this.compJoker.AutoSize = true;
            this.compJoker.Location = new System.Drawing.Point(574, 143);
            this.compJoker.Name = "compJoker";
            this.compJoker.Size = new System.Drawing.Size(13, 13);
            this.compJoker.TabIndex = 18;
            this.compJoker.Text = "0";
            // 
            // compPink
            // 
            this.compPink.AutoSize = true;
            this.compPink.Location = new System.Drawing.Point(401, 281);
            this.compPink.Name = "compPink";
            this.compPink.Size = new System.Drawing.Size(13, 13);
            this.compPink.TabIndex = 18;
            this.compPink.Text = "0";
            // 
            // compYellow
            // 
            this.compYellow.AutoSize = true;
            this.compYellow.Location = new System.Drawing.Point(468, 281);
            this.compYellow.Name = "compYellow";
            this.compYellow.Size = new System.Drawing.Size(13, 13);
            this.compYellow.TabIndex = 18;
            this.compYellow.Text = "0";
            // 
            // compRed
            // 
            this.compRed.AutoSize = true;
            this.compRed.Location = new System.Drawing.Point(541, 281);
            this.compRed.Name = "compRed";
            this.compRed.Size = new System.Drawing.Size(13, 13);
            this.compRed.TabIndex = 18;
            this.compRed.Text = "0";
            // 
            // plusComp
            // 
            this.plusComp.Image = global::Coloretto.Properties.Resources._2;
            this.plusComp.Location = new System.Drawing.Point(356, 46);
            this.plusComp.Name = "plusComp";
            this.plusComp.Size = new System.Drawing.Size(61, 92);
            this.plusComp.TabIndex = 17;
            this.plusComp.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Coloretto.Properties.Resources._2;
            this.pictureBox8.Location = new System.Drawing.Point(7, 46);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(61, 92);
            this.pictureBox8.TabIndex = 17;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Coloretto.Properties.Resources.Blue;
            this.pictureBox9.Location = new System.Drawing.Point(74, 46);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(61, 92);
            this.pictureBox9.TabIndex = 17;
            this.pictureBox9.TabStop = false;
            // 
            // blueComp
            // 
            this.blueComp.Image = global::Coloretto.Properties.Resources.Blue;
            this.blueComp.Location = new System.Drawing.Point(423, 46);
            this.blueComp.Name = "blueComp";
            this.blueComp.Size = new System.Drawing.Size(61, 92);
            this.blueComp.TabIndex = 17;
            this.blueComp.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::Coloretto.Properties.Resources.Green;
            this.pictureBox10.Location = new System.Drawing.Point(141, 46);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(61, 92);
            this.pictureBox10.TabIndex = 17;
            this.pictureBox10.TabStop = false;
            // 
            // greenComp
            // 
            this.greenComp.Image = global::Coloretto.Properties.Resources.Green;
            this.greenComp.Location = new System.Drawing.Point(490, 46);
            this.greenComp.Name = "greenComp";
            this.greenComp.Size = new System.Drawing.Size(61, 92);
            this.greenComp.TabIndex = 17;
            this.greenComp.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::Coloretto.Properties.Resources.Joker;
            this.pictureBox11.Location = new System.Drawing.Point(208, 46);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(61, 92);
            this.pictureBox11.TabIndex = 17;
            this.pictureBox11.TabStop = false;
            // 
            // jokerComp
            // 
            this.jokerComp.Image = global::Coloretto.Properties.Resources.Joker;
            this.jokerComp.Location = new System.Drawing.Point(557, 46);
            this.jokerComp.Name = "jokerComp";
            this.jokerComp.Size = new System.Drawing.Size(61, 92);
            this.jokerComp.TabIndex = 17;
            this.jokerComp.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::Coloretto.Properties.Resources.Purple;
            this.pictureBox12.Location = new System.Drawing.Point(41, 186);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(61, 92);
            this.pictureBox12.TabIndex = 17;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::Coloretto.Properties.Resources.Purple;
            this.pictureBox19.Location = new System.Drawing.Point(390, 186);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(61, 92);
            this.pictureBox19.TabIndex = 17;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::Coloretto.Properties.Resources.Yellow;
            this.pictureBox13.Location = new System.Drawing.Point(108, 186);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(61, 92);
            this.pictureBox13.TabIndex = 17;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = global::Coloretto.Properties.Resources.Yellow;
            this.pictureBox20.Location = new System.Drawing.Point(457, 186);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(61, 92);
            this.pictureBox20.TabIndex = 17;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::Coloretto.Properties.Resources.Red;
            this.pictureBox14.Location = new System.Drawing.Point(175, 186);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(61, 92);
            this.pictureBox14.TabIndex = 17;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = global::Coloretto.Properties.Resources.Red;
            this.pictureBox21.Location = new System.Drawing.Point(524, 186);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(61, 92);
            this.pictureBox21.TabIndex = 17;
            this.pictureBox21.TabStop = false;
            // 
            // ScoreScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(625, 534);
            this.Controls.Add(this.plusComp);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.compRed);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.compYellow);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.compPink);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.compJoker);
            this.Controls.Add(this.blueComp);
            this.Controls.Add(this.compGreen);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.compBlue);
            this.Controls.Add(this.greenComp);
            this.Controls.Add(this.compPlus);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.playerRed);
            this.Controls.Add(this.jokerComp);
            this.Controls.Add(this.playerYellow);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.playerPink);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.playerJoker);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.playerGreen);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.playerBlue);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.playerPlus);
            this.Controls.Add(this.pictureBox21);
            this.Name = "ScoreScreen";
            this.Text = "ScoreScreen";
            this.Load += new System.EventHandler(this.ScoreScreen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.plusComp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blueComp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.greenComp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jokerComp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox plusComp;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox blueComp;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox greenComp;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox jokerComp;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.Label playerPlus;
        private System.Windows.Forms.Label playerBlue;
        private System.Windows.Forms.Label playerGreen;
        private System.Windows.Forms.Label playerJoker;
        private System.Windows.Forms.Label playerPink;
        private System.Windows.Forms.Label playerYellow;
        private System.Windows.Forms.Label playerRed;
        private System.Windows.Forms.Label compPlus;
        private System.Windows.Forms.Label compBlue;
        private System.Windows.Forms.Label compGreen;
        private System.Windows.Forms.Label compJoker;
        private System.Windows.Forms.Label compPink;
        private System.Windows.Forms.Label compYellow;
        private System.Windows.Forms.Label compRed;
    }
}