﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Coloretto
{
    public partial class ScoreScreen : Form
    {
        Player player = new Player();
        Player computer = new Player();
        public ScoreScreen()
        {
            InitializeComponent();
        }

        private void playerPlus_Click(object sender, EventArgs e)
        {

        }

        private void ScoreScreen_Load(object sender, EventArgs e)
        {

        }
    }
}
