﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace Coloretto
{
    /// <summary>
    /// Subclass of Cardclass
    /// Bonus +2 points card
    /// </summary>
    class BonusCard : CardClass
    {
        public BonusCard()
        {
            cardName = "Bonus +2 points";
            cardType = "Bonus";
            image = new System.Drawing.Bitmap(@"21.gif");
            imageLoc = @"21.gif";
            Contract.Ensures(cardName != null);
            Contract.Ensures(cardType != null);
            Contract.Ensures(image != null);
            Contract.Ensures(imageLoc != null);
        }
    }
}
