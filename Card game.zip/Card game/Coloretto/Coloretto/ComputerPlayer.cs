﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace Coloretto
{
    /// <summary>
    /// Subclass of Player, this has additional methods that the computer will use to perform tasks
    /// </summary>
    class ComputerPlayer : Player
    {
        /// <summary>
        /// Computer takes row
        /// checks if row contains cards
        /// Takes it if true
        /// </summary>
        public void compTakeRow(ArrayList RowOne, ArrayList RowTwo, ArrayList RowThree, Player computer, PictureBox pictureBox2, PictureBox pictureBox3, PictureBox pictureBox4, PictureBox pictureBox5, PictureBox pictureBox6, PictureBox pictureBox7)
        {
            if (RowOne.Count > 0)
            {
                for (int c = 0; c < RowOne.Count; c++)
                {
                    computer.setHand(RowOne[c]);
                    computer.countCards();
                    pictureBox2.ImageLocation = null;
                    pictureBox3.ImageLocation = null;
                    pictureBox4.ImageLocation = null;
                    RowOne.Clear();
                }
            }
            else if (RowTwo.Count > 0)
            {
                for (int c = 0; c < RowTwo.Count; c++)
                {
                    computer.setHand(RowTwo[c]);
                    computer.countCards();
                    pictureBox5.ImageLocation = null;
                    pictureBox6.ImageLocation = null;
                    RowTwo.Clear();
                }
            }
            else
            {
                for (int c = 0; c < RowThree.Count; c++)
                {
                    computer.setHand(RowThree[c]);
                    computer.countCards();
                    pictureBox7.ImageLocation = null;
                    RowThree.Clear();
                }
            }

        }

        /// <summary>
        /// Randomly places cards in a row
        /// Rerandoms if the randomly chosen spot already has a card in it
        /// This method will not be run if all the rows are full
        /// </summary>
        public int compPlaceCard(ArrayList deck, int deckCount, PictureBox pictureBox2, PictureBox pictureBox3, PictureBox pictureBox4, PictureBox pictureBox5, PictureBox pictureBox6, PictureBox pictureBox7, PictureBox lastCard, ArrayList RowOne, ArrayList RowTwo, ArrayList RowThree)
        {
            bool done = false;
            Random r = new Random();
            CardClass temp = (CardClass)deck[deckCount];
            PictureBox[] boxes;
            boxes = new PictureBox[6];
            boxes[0] = (pictureBox2);
            boxes[1] = (pictureBox3);
            boxes[2] = (pictureBox4);
            boxes[3] = (pictureBox5);
            boxes[4] = (pictureBox6);
            boxes[5] = (pictureBox7);
            int random = r.Next(0, 6);
            while (!done)
            {
                random = r.Next(0, 6);
                if (!done)
                {
                    if (temp.getType() == "Last Round")
                    {
                        lastCard.ImageLocation = temp.getImageLoc();
                        deckCount++;
                        temp = (CardClass)deck[deckCount];
                    }
                    if (boxes[random].ImageLocation == @"14.gif")
                    {
                        boxes[random].ImageLocation = temp.getImageLoc();
                        if (random < 3)
                        {
                            RowOne.Add(deck[deckCount]);
                        }
                        else if (random < 5)
                        {
                            RowTwo.Add(deck[deckCount]);
                        }
                        else
                        {
                            RowThree.Add(deck[deckCount]);
                        }
                        deckCount++;
                        done = true;
                    }
                }
            }
            return deckCount;
        }
        /// <summary>
        ///loops through rows looking for +2 cards if true, loop through that row again taking each card.
        /// </summary>
        public bool AiDecision(ArrayList RowOne, ArrayList RowTwo, ArrayList RowThree, Player computer, PictureBox pictureBox2, PictureBox pictureBox3, PictureBox pictureBox4, PictureBox pictureBox5, PictureBox pictureBox6, PictureBox pictureBox7)
        {
            bool takeRow = false;
            CardClass card = new CardClass();
            //rowone - check row one for bonus cards
            for (int c = 0; c < RowOne.Count; c++)
            {
                card = (CardClass)RowOne[c];
                if (card.getType() == "Bonus")
                {
                    takeRow = true;
                }
            }
            if (takeRow)
            {
                for (int c = 0; c < RowOne.Count; c++)
                {
                    card = (CardClass)RowOne[c];
                    computer.setHand(card);
                }
                computer.countCards();

                pictureBox2.ImageLocation = null;
                pictureBox3.ImageLocation = null;
                pictureBox4.ImageLocation = null;
                RowOne.Clear();
                return true;
            }
            //rowone^^^

            //rowtwo - check row two for bonus cards
            for (int c = 0; c < RowTwo.Count; c++)
            {
                card = (CardClass)RowTwo[c];
                if (card.getType() == "Bonus")
                {
                    takeRow = true;
                }
            }
            if (takeRow)
            {
                for (int c = 0; c < RowTwo.Count; c++)
                {
                    card = (CardClass)RowTwo[c];
                    computer.setHand(card);
                }
                computer.countCards();

                pictureBox5.ImageLocation = null;
                pictureBox6.ImageLocation = null;
                RowTwo.Clear();
                return true;
            }
            //rowtwo^^^

            //rowthree - check row three for bonus cards
            for (int c = 0; c < RowThree.Count; c++)
            {
                card = (CardClass)RowThree[c];
                if (card.getType() == "Bonus")
                {
                    takeRow = true;
                }
            }
            if (takeRow)
            {
                for (int c = 0; c < RowThree.Count; c++)
                {
                    card = (CardClass)RowThree[c];
                    computer.setHand(card);
                }
                computer.countCards();

                pictureBox7.ImageLocation = null;
                RowThree.Clear();
                return true;
            }
            //rowthree^^^
            return false;//if found no bonus cards return false

        }
    }
}
