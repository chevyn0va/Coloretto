﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
namespace Coloretto
{
    /// <summary>
    /// Two methods that the form uses frequently
    /// </summary>
    class Game
    {
        /// <summary>
        /// Calculate players points
        /// </summary>
        /// <param name="player"></param>
        public void calcPointsP(Player player)
        {
            List<int> playerList = new List<int>();
            playerList.Add(player.getBlue());
            playerList.Add(player.getGreen());
            playerList.Add(player.getPurple());
            playerList.Add(player.getRed());
            playerList.Add(player.getYellow());
            int plus = 0;
            int jokers = player.getJoker();

            //calc colour points
            int pPoints = 0;
            for (int c = 0; c < 3; c++)
            {
                int maxIndex = playerList.IndexOf(playerList.Max());
                plus = playerList[maxIndex];
                if (jokers > 0)
                {
                    plus = plus + jokers;
                    jokers = 0;
                }
                if (plus == 1)
                {
                    pPoints = pPoints + 1;
                }
                else if (plus == 2)
                {
                    pPoints = pPoints + 3;
                }
                else if (plus == 3)
                {
                    pPoints = pPoints + 6;
                }
                else if (plus == 4)
                {
                    pPoints = pPoints + 10;
                }
                else if (plus == 5)
                {
                    pPoints = pPoints + 15;
                }
                else if (plus > 5)
                {
                    pPoints = pPoints + 21;
                }
                else
                {
                }
                playerList.RemoveAt(maxIndex);
            }
            //calc colour points^^


            //calc minus colour points
            for (int c = 0; c < 2; c++)
            {
                if (playerList[c] == 1)
                {
                    pPoints = pPoints - 1;
                }
                else if (playerList[c] == 2)
                {
                    pPoints = pPoints - 3;
                }
                else if (playerList[c] == 3)
                {
                    pPoints = pPoints - 6;
                }
                else if (playerList[c] == 4)
                {
                    pPoints = pPoints - 10;
                }
                else if (playerList[c] == 5)
                {
                    pPoints = pPoints - 15;
                }
                else if (playerList[c] > 5)
                {
                    pPoints = pPoints - 21;
                }
                else
                {
                }
            }


            //calc additional points
            int _2 = player.get_2();
            _2 = _2 * 2;
            pPoints = pPoints + _2;


            player.setPoints(pPoints);
 
        }
        /// <summary>
        /// Check if the round is over
        /// If round is over check if it is the last round, if last round end game if not continue to next round
        /// </summary>
        public bool checkRound(bool playerTaken, bool computerTaken, PictureBox pictureBox2, PictureBox pictureBox3, PictureBox pictureBox4, PictureBox pictureBox5, PictureBox pictureBox6, PictureBox pictureBox7, ArrayList RowOne, ArrayList RowTwo, ArrayList RowThree)
        {
            if (playerTaken && computerTaken)
            {
                pictureBox2.ImageLocation = @"14.gif";
                pictureBox3.ImageLocation = @"14.gif";
                pictureBox4.ImageLocation = @"14.gif";
                pictureBox5.ImageLocation = @"14.gif";
                pictureBox6.ImageLocation = @"14.gif";
                pictureBox7.ImageLocation = @"14.gif";
                RowOne.Clear();
                RowTwo.Clear();
                RowThree.Clear();

                return false;
            }
            return true;
        }

    }
}
