﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace Coloretto
{
    /// <summary>
    /// Subclass of cardclass
    /// All 5 colour cards
    /// This class is different as is it must set its picture and name depending on what colour it is.
    /// The constructor simply recieves the name as a parameter and uses that to determine what picture to set as the image location
    /// </summary>
    class ColorCard : CardClass
    {
        public ColorCard(String name)
        {
            cardName = name;
            cardType = "Color";
            if (cardName == "Green")
            {
                image = new System.Drawing.Bitmap(@"25.gif");
                imageLoc = @"25.gif";

            }
            else if (cardName == "Yellow")
            {
                image = new System.Drawing.Bitmap(@"28.gif");
                imageLoc = @"28.gif";
            }
            else if (cardName == "Blue")
            {
                image = new System.Drawing.Bitmap(@"24.gif");
                imageLoc = @"24.gif";
            }
            else if (cardName == "Red")
            {
                image = new System.Drawing.Bitmap(@"23.gif");
                imageLoc = @"23.gif";
            }
            else if (cardName == "Pink")
            {
                image = new System.Drawing.Bitmap(@"22.gif");
                imageLoc = @"22.gif";
            }
            Contract.Ensures(cardName != null);
            Contract.Ensures(cardType != null);
            Contract.Ensures(image != null);
            Contract.Ensures(imageLoc != null);
        }
    }
}
