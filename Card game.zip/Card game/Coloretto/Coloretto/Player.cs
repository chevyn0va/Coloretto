﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace Coloretto
{
    class Player
    {
        protected ArrayList PlayerHand = new ArrayList();//cards in the players hand
        //count for each card the player has in hand
        protected int yellow = 0;
        protected int blue = 0;
        protected int green = 0;
        protected int red = 0;
        protected int purple = 0;
        protected int joker = 0;
        protected int _2 = 0;
        protected int points = 0;

        //get methods for the form to access the above variables
        public int getYellow()
        {
            return yellow;
        }
        public int getPoints()
        {
            return points;
        }
        public int getBlue()
        {
            return blue;
        }
        public int getGreen()
        {
            return green;
        }
        public int getRed()
        {
            return red;
        }
        public int getPurple()
        {
            return purple;
        }
        public int getJoker()
        {
            return joker;
        }
        public int get_2()
        {
            return _2;
        }

        /// <summary>
        /// set the players points
        /// </summary>
        public void setPoints(int p)
        {
            points = p;
        }
        /// <summary>
        /// Add a card to the players hand
        /// </summary>
        public void setHand(Object card)
        {
            this.PlayerHand.Add((CardClass)card);
        }
        /// <summary>
        /// Get method
        /// </summary>
        public ArrayList getHand()
        {
            return this.PlayerHand;
        }
        /// <summary>
        /// Count how many of each card the player has in hand
        /// </summary>
        public void countCards()
        {
            yellow = 0;
            blue = 0;
            green = 0;
            red = 0;
            purple = 0;
            joker = 0;
            _2 = 0;
            for (int c = 0; c < PlayerHand.Count; c++)
            {

                CardClass temp = (CardClass)PlayerHand[c];

                String name = temp.getName();

                if (name == "Green")
                {
                    green++;

                }
                else if (name == "Yellow")
                {
                    yellow++;
                }
                else if (name == "Blue")
                {
                    blue++;
                }
                else if (name == "Red")
                {
                    red++;
                }
                else if (name == "Pink")
                {
                    purple++;
                }
                else if (name == "Bonus +2 points")
                {
                    _2++;
                }
                else if (name == "Joker")
                {
                    joker++;
                }

            }
        }
        /// <summary>
        /// Places a card in chosen row
        /// Returns true if success
        /// </summary>
        public virtual bool playerPlaceCard(PictureBox pictureBoxTemp, PictureBox currentCard, ArrayList Row, int deckCount, ArrayList deck)
        {

            if (pictureBoxTemp.ImageLocation == @"14.gif")
                {
                    pictureBoxTemp.ImageLocation = currentCard.ImageLocation;
                    currentCard.Image = null;
                    Row.Add(deck[deckCount]);
                    deckCount++;
                    return true;
                }
            return false;
            
        }

    }
}
