﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;


namespace Coloretto
{
    public partial class Form1 : Form
    {
        Player player = new Player(); //player object represents human player
        ComputerPlayer computer = new ComputerPlayer();//player object represents computer player
        private ArrayList deck = new ArrayList();//contains 58 card objects
        private ArrayList RowOne = new ArrayList();//contains up to 3 cards
        private ArrayList RowTwo = new ArrayList();//contains up to 2 cards
        private ArrayList RowThree = new ArrayList();//contains up to 1 card
        private bool playersTaken = false;//true when computer/player has taken a row, used to start a new round
        private bool computersTaken = false;
        private bool lastRound = false;//true once last round card has been drawn
        private Random r = new Random(); //computer player uses to place a card in a row
        //private bool rowsFull = false;
        Game gameCalcs = new Game();//contains calcPoints and checkRound        
        private bool mouseGo = false;//allows player to place a card
        private int deckCount = 0;//current place in the deck

        public Form1()
        {
            InitializeComponent();

        }

        /// <summary>
        /// Create and shuffle deck on form load
        /// Set pictureboxes
        /// Change variable in here for shorter game
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = ("Draw a card by pressing the 'Draw Card' button\n");
            pictureBox2.ImageLocation = @"14.gif";
            pictureBox3.ImageLocation = @"14.gif";
            pictureBox4.ImageLocation = @"14.gif";
            pictureBox5.ImageLocation = @"14.gif";
            pictureBox6.ImageLocation = @"14.gif";
            pictureBox7.ImageLocation = @"14.gif";
            int count = 0;
            while (count != 45)
            {
                ColorCard card;
                if (count < 9)
                {
                    card = new ColorCard("Green");
                }
                else if(count < 18)
                {
                    card = new ColorCard("Yellow");
                }
                else if (count < 27)
                {
                    card = new ColorCard("Blue");
                }
                else if (count < 36)
                {
                    card = new ColorCard("Red");
                }
                else
                {
                    card = new ColorCard("Pink");
                }
                deck.Add(card);
                count++;
            }
            
            while (count != 48)
            {
                JokerClass card = new JokerClass();
                deck.Add(card);
                count++;
            }

            while (count != 58)
            {
                BonusCard card = new BonusCard();
                deck.Add(card);
                count++;
            }

            count = 0;
            while (count != 58)
            {
                Console.WriteLine(deck[count] + "    " + count);
                count++;
            }

            //shuffle deck
            deck = Form1.Shuffle(deck);

            //place last round card in the deck 15 cards from the end
            EndGameCard card2 = new EndGameCard();
            Console.WriteLine("\n" + deck[57]);
            count = 57;
            while (count != 42)
            {
                deck[count] = deck[count - 1];
                count--;
            }
            deck[42] = card2; //change value in array for shorter games--------------------------------------------
            //42

            Console.WriteLine("\n\n");
            count = 0;
            while (count != 58)
            {
                Console.WriteLine(deck[count] + "    " + count);
                count++;
            }

            //draw 4 cards for players to start with
            player.setHand(deck[0]);
            computer.setHand(deck[1]);
            player.setHand(deck[2]);
            computer.setHand(deck[3]);
            deckCount = 4;
            player.countCards();
            computer.countCards();
            countCards();
        }

        /// <summary>
        /// method from here
        /// http://stackoverflow.com/questions/273313/randomize-a-listt-in-c
        /// edited slightly to suit my program
        /// Method shuffles the indexes within an arraylist
        /// </summary>
        /// <param name="list">deck</param>
        /// <returns>shuffled deck</returns>
        public static ArrayList Shuffle(ArrayList list)
        {
            Random rng = new Random();
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                Object value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
            return list;
        }

        /// <summary>
        /// Draw card from the deck
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            //must be a free space to place card in order to draw one
            if (pictureBox2.ImageLocation == @"14.gif" || pictureBox3.ImageLocation == @"14.gif" || pictureBox4.ImageLocation == @"14.gif" || pictureBox5.ImageLocation == @"14.gif" || pictureBox6.ImageLocation == @"14.gif" || pictureBox7.ImageLocation == @"14.gif")
            {
                textBox1.Text = ("Place the card you have drawn in a row by clicking on one of the 3 rows picture boxes'");
                CardClass temp = (CardClass)deck[deckCount];

                //if last round card is drawn, draw another card and finish round
                if (temp.getType() == "Last Round")
                {
                    lastCard.Image = temp.getImage();
                    currentCard.ImageLocation = temp.getImageLoc();
                    mouseGo = false;
                    lastRound = true;
                    deckCount++;
                }
                mouseGo = true;
                temp = (CardClass)deck[deckCount];
                currentCard.ImageLocation = temp.getImageLoc();
            }
        }
        /// <summary>
        /// click event for clicking on picture box (placing a card in a row)
        /// </summary>
        private void pictureBox2_Click(object sender, EventArgs e)
        {

            if (mouseGo)
            {
                textBox1.Text = ("Option 1: Draw a card by pressing the 'Draw Card' button \nOption 2: Take the cards in a row by pressing the 'Take Row' button.");
                //place card in row
                if (player.playerPlaceCard(pictureBox2, currentCard, RowOne, deckCount, deck))
                {
                    deckCount++;
                    //computer makes its move if it hasnt already taken a row
                    if (!computersTaken)
                    {
                        computersTurn();
                    }
                    countCards();
                }
                mouseGo = false;
            } 
        }
        /// <summary>
        /// click event for clicking on picture box (placing a card in a row)
        /// </summary>
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (mouseGo)
            {
                textBox1.Text = ("Option 1: Draw a card by pressing the 'Draw Card' button \nOption 2: Take the cards in a row by pressing the 'Take Row' button.");
                //place card in row
                if (player.playerPlaceCard(pictureBox3, currentCard, RowOne, deckCount, deck))
                {
                    deckCount++;
                    //computer makes its move if it hasnt already taken a row
                    if (!computersTaken)
                    {
                        computersTurn();
                    }
                    countCards();
                }
                mouseGo = false;
            }
        }
        /// <summary>
        /// click event for clicking on picture box (placing a card in a row)
        /// </summary>
        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (mouseGo)
            {
                textBox1.Text = ("Option 1: Draw a card by pressing the 'Draw Card' button \nOption 2: Take the cards in a row by pressing the 'Take Row' button.");
                //place card in row
                if (player.playerPlaceCard(pictureBox4, currentCard, RowOne, deckCount, deck))
                {
                    deckCount++;
                    //computer makes its move if it hasnt already taken a row
                    if (!computersTaken)
                    {
                        computersTurn();
                    }
                    countCards();
                }
                mouseGo = false;
            }

        }
        /// <summary>
        /// click event for clicking on picture box (placing a card in a row)
        /// </summary>
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            if (mouseGo)
            {
                textBox1.Text = ("Option 1: Draw a card by pressing the 'Draw Card' button \nOption 2: Take the cards in a row by pressing the 'Take Row' button.");
                //place card in row
                if (player.playerPlaceCard(pictureBox5, currentCard, RowTwo, deckCount, deck))
                {
                    deckCount++;
                    //computer makes its move if it hasnt already taken a row
                    if (!computersTaken)
                    {
                        computersTurn();
                    }
                    countCards();
                }
                mouseGo = false;
            }

        }
        /// <summary>
        /// click event for clicking on picture box (placing a card in a row)
        /// </summary>
        private void pictureBox6_Click(object sender, EventArgs e)
        {
            if (mouseGo)
            {
                textBox1.Text = ("Option 1: Draw a card by pressing the 'Draw Card' button \nOption 2: Take the cards in a row by pressing the 'Take Row' button.");
                //place card in row
                if (player.playerPlaceCard(pictureBox6, currentCard, RowTwo, deckCount, deck))
                {
                    deckCount++;
                    //computer makes its move if it hasnt already taken a row
                    if (!computersTaken)
                    {
                        computersTurn();
                    }
                    countCards();
                }
                mouseGo = false;
            }
            
            
        }
        /// <summary>
        /// click event for clicking on picture box (placing a card in a row)
        /// </summary>
        private void pictureBox7_Click(object sender, EventArgs e)
        {
            if (mouseGo)
            {
                textBox1.Text = ("Option 1: Draw a card by pressing the 'Draw Card' button \nOption 2: Take the cards in a row by pressing the 'Take Row' button."); textBox1.Text = ("Draw a card by pressing the 'Draw Card' button\n");
                //place card in row
                if (player.playerPlaceCard(pictureBox7, currentCard, RowThree, deckCount, deck))
                {
                    deckCount++;
                    //computer makes its move if it hasnt already taken a row
                    if (!computersTaken)
                    {
                        computersTurn();
                    }
                    countCards();
                }
                mouseGo = false;
            }
            
        }

        private void currentCard_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Take respective row and add it to the players hand
        /// </summary>
        private void take1_Click(object sender, EventArgs e) 
        {
            if (!mouseGo){
                if (RowOne.Count != 0)
                {
                    for (int c = 0; c < RowOne.Count; c++)
                    {
                        try
                        {
                            player.setHand(RowOne[c]);
                        }
                        catch (ArgumentOutOfRangeException)
                        {
                        }
                    }

                    player.countCards();
                    countCards();
                    //initilize row
                    pictureBox2.ImageLocation = null;
                    pictureBox3.ImageLocation = null;
                    pictureBox4.ImageLocation = null;
                    RowOne.Clear();
                    playersTaken = true;
                    //computer loops its turn until it takes a row
                    while (!computersTaken)
                    {
                        computersTurn();
                    }
                    checkFinish();
                    textBox1.Text = ("Draw a card by pressing the 'Draw Card' button\n");
                }
            }          
        }
        /// <summary>
        /// Take respective row and add it to the players hand
        /// </summary>
        private void take2_Click(object sender, EventArgs e)
        {
            if (!mouseGo)
            {
                if (RowTwo.Count != 0)
                {

                    for (int c = 0; c < RowTwo.Count; c++)
                    {
                        try
                        {
                            player.setHand(RowTwo[c]);
                        }
                        catch (ArgumentOutOfRangeException)
                        {
                        }
                    }
                    player.countCards();
                    countCards();
                    //initilize row
                    pictureBox5.ImageLocation = null;
                    pictureBox6.ImageLocation = null;
                    RowTwo.Clear();
                    playersTaken = true;
                    //computer loops its turn until it takes a row
                    while (!computersTaken)
                    {
                        computersTurn();
                    }
                    checkFinish();
                    textBox1.Text = ("Draw a card by pressing the 'Draw Card' button\n");
                }
            }
        }
        /// <summary>
        /// Take respective row and add it to the players hand
        /// </summary>
        private void take3_Click(object sender, EventArgs e)
        {
            if (!mouseGo)
            {
                if (RowThree.Count != 0)
                {
                    for (int c = 0; c < RowThree.Count; c++)
                    {
                        try
                        {
                            player.setHand(RowThree[c]);
                        }
                        catch (ArgumentOutOfRangeException)
                        {
                        }
                    }
                    player.countCards();
                    countCards();
                    //initilize row
                    pictureBox7.ImageLocation = null;
                    RowThree.Clear();
                    playersTaken = true;
                    //computer loops its turn until it takes a row
                    while (!computersTaken)
                    {
                        computersTurn();
                    }
                    checkFinish();
                    textBox1.Text = ("Draw a card by pressing the 'Draw Card' button\n");
                }
            }
        }

        private void playerPlus_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Gets card counts from player objects and sets them
        /// to labels for user to see current card counts
        /// </summary>
        private void countCards()
        {
            playerBlue.Text = player.getBlue().ToString();
            playerGreen.Text = player.getGreen().ToString();
            playerPlus.Text = player.get_2().ToString();
            playerJoker.Text = player.getJoker().ToString();
            playerPink.Text = player.getPurple().ToString();
            playerRed.Text = player.getRed().ToString();
            playerYellow.Text = player.getYellow().ToString();
            compBlue.Text = computer.getBlue().ToString();
            compGreen.Text = computer.getGreen().ToString();
            compPlus.Text = computer.get_2().ToString();
            compJoker.Text = computer.getJoker().ToString();
            compPink.Text = computer.getPurple().ToString();
            compRed.Text = computer.getRed().ToString();
            compYellow.Text = computer.getYellow().ToString();
        }

        /// <summary>
        /// This method after each of the users turns.
        /// This method determines what the computer will do (AI)
        /// It will choose one of three options, the top priority option is taking a row with a +2 points 
        /// card in it, the second priority is placing another card into the row (this is to increase the chance
        /// a +2 points card is to be drawn into the rows), the last priority option is to take the row
        /// with the most cards.
        /// </summary>
        private void computersTurn()
        {

            //option 1, search for +2 card in rows
            if (computer.AiDecision(RowOne, RowTwo, RowThree, computer, pictureBox2, pictureBox3, pictureBox4, pictureBox5, pictureBox6, pictureBox7))
            {
                computersTaken = true;
            }
                //option 2, place another card in a row
            else if (pictureBox2.ImageLocation == @"14.gif" || pictureBox3.ImageLocation == @"14.gif" || pictureBox4.ImageLocation == @"14.gif" || pictureBox5.ImageLocation == @"14.gif" || pictureBox6.ImageLocation == @"14.gif" || pictureBox7.ImageLocation == @"14.gif")
            {
                deckCount = computer.compPlaceCard(deck, deckCount, pictureBox2, pictureBox3, pictureBox4, pictureBox5, pictureBox6, pictureBox7, lastCard, RowOne, RowTwo, RowThree);
            }
                //option 3 take the row with the most cards
            else
            {
                computer.compTakeRow(RowOne, RowTwo, RowThree, computer, pictureBox2, pictureBox3, pictureBox4, pictureBox5, pictureBox6, pictureBox7);
                computersTaken = true;
            }
            countCards();
            if (lastCard.ImageLocation != null)//if the computer drew the lastround card
            {
                lastRound = true;
            }
        }

       
        /// <summary>
        /// Checks if the the round is over
        /// if round is over check if the last round has been drawn and end game
        /// </summary>
        private void checkFinish()
        {
           if (!gameCalcs.checkRound(playersTaken, computersTaken, pictureBox2, pictureBox3, pictureBox4, pictureBox5, pictureBox6, pictureBox7, RowOne, RowTwo, RowThree))
            {
                playersTaken = false;
                computersTaken = false;
                if (lastRound)// if last round end game by displaying points
                {
                    gameCalcs.calcPointsP(computer);
                    gameCalcs.calcPointsP(player);
                    DialogResult r1 = MessageBox.Show("Player Scored: " + player.getPoints() + "\nComputer Scored: " + computer.getPoints() + "\n\nWould you like to play again?", "", MessageBoxButtons.YesNo);
                    if (r1 == System.Windows.Forms.DialogResult.No)
                    {
                        this.Close();
                    }
                    else
                    {
                        this.Visible = false;
                        Form f = new Form1();//create new form for a new game
                        f.Visible = true;
                    }
                }
            }
        }

        private void lastCard_Click(object sender, EventArgs e)
        {

        }

    }
}
