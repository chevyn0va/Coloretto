﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace Coloretto
{
    /// <summary>
    /// Subclass of Cardclass
    /// Joker card
    /// </summary>
    class JokerClass : CardClass
    {
        public JokerClass()
        {
            cardName = "Joker";
            cardType = "Joker";
            image = new System.Drawing.Bitmap(@"27.gif");
            imageLoc = @"27.gif";
            Contract.Ensures(cardName != null);
            Contract.Ensures(cardType != null);
            Contract.Ensures(image != null);
            Contract.Ensures(imageLoc != null);
        }

    }
}
